# Website

Official Repository for Website hosted for Anokhya'24 Tech Fest.

## Tech Stack
- React
- CSS

The website is hosted on Netlify. [Link](https://anokhya.netlify.app/)

## Build and Deploy

Clone the repo and in the root folder run

`npm install`
`npm run dev`

to start app on [`localhost:5731`](localhost:5173)# anokhya2024
